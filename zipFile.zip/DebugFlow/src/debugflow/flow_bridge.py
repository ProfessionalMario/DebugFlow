import socket
import json
import traceback
from . import log
import uuid
import os
import inspect # Added for signature inspection


class Flow:
    _instance = None
    run_id = None

    def __init__(self, host="127.0.0.1", port=5555):
        self.host = host
        self.port = port
        Flow._instance = self  # singleton reference
    
    @staticmethod
    def init(sync_id):
        """
        The Shielded Init: Safely establishes the synapse connection.
        """
        try:
            # Set the Session Identity
            os.environ["FLOW_SYNC_ID"] = sync_id
            
            # Attempt to verify the connection to the Sentinel/HUD
            # We use a short timeout to prevent the user's script from hanging
            with socket.create_connection(("127.0.0.1", 5555), timeout=0.5):
                Flow._connected = True
                # Silent success: We don't flood the terminal here
        
        except (ConnectionRefusedError, socket.timeout):
            # Fail Gracefully: The engine continues, but in 'Silent' mode
            Flow._connected = False
            # We print a clean, branded warning instead of a traceback
            print("  ⚠️  [SYNAPSE OFFLINE]: HUD not detected. Running in headless mode.")
            
        except Exception as e:
            # The 'Emergency Brake': Catch-all for unexpected environment issues
            Flow._connected = False
            print(f"  🛑  [INIT_FAILURE]: NeuralFlow could not bridge. Error: {str(e)[:50]}...")
    @staticmethod
    def pulse(node, params=None, returns=None, type="pulse"):
        try:
            if Flow._instance is None: Flow()
            
            node_name = node.__name__ if callable(node) else str(node)
            final_type = type
            display_params = params
            display_returns = returns

            # --- THE DUAL-GATE VALIDATION ---
            if callable(node):
                try:
                    sig = inspect.signature(node)
                    
                    # GATE 1: Input Mismatch (Nuke on Entry)
                    if isinstance(params, dict):
                        for key, val in params.items():
                            if key in sig.parameters:
                                expected = sig.parameters[key].annotation
                                if expected is not inspect._empty and not isinstance(val, expected):
                                    final_type = "nuke"
                                    want = getattr(expected, "__name__", str(expected))
                                    got = type(val).__name__
                                    display_params = f"CRIT_FAIL [IN]: '{key}' wanted {want}, got {got}"
                                    break

                    # GATE 2: Return Mismatch (Nuke on Exit)
                    if returns is not None:
                        expected_ret = sig.return_annotation
                        if expected_ret is not inspect._empty and not isinstance(returns, expected_ret):
                            final_type = "nuke"
                            want_ret = getattr(expected_ret, "__name__", str(expected_ret))
                            got_ret = type(returns).__name__
                            display_returns = f"CRIT_FAIL [OUT]: wanted {want_ret}, got {got_ret}"

                except Exception:
                    pass

            payload = {
            "run_id": str(Flow.run_id or "DEV_SESH"),
            "flow_mode": os.environ.get("FLOW_MODE", "SIMULATION"), # Add this line
            "node": node_name,
            "params": display_params,
            "returns": display_returns,
            "type": final_type
            }

            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.1)
                s.connect((Flow._instance.host, Flow._instance.port))
                # s.sendall(json.dumps(payload).encode("utf-8"))
                s.sendall(json.dumps(payload, ensure_ascii=False).encode("utf-8"))

        except Exception:
            pass
        
    @staticmethod
    def nuke(node_name, error_msg):
        Flow.pulse(node_name, params=error_msg, type="nuke")

    def start_run(self, entry_func, *args, **kwargs):
        self.run_id = uuid.uuid4().hex[:8]
        log.info(f"[FLOW] Starting run_id = {self.run_id}")
        env = os.environ.copy()
        env["FLOW_RUN_ID"] = self.run_id
        return entry_func(*args, flow=self, **kwargs)