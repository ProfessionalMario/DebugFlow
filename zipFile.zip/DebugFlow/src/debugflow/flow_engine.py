

import builtins
import sys
import os
import inspect
import time
import socket
import traceback
import importlib.util
import subprocess
from . import log
from .flow_bridge import Flow

# This automatically connects to your LoggerSystem because it's under 'debugflow'
# log = logging.getLogger("debugflow.engine")
from debugflow import log
class FlowEngine:
    @staticmethod
    def ignite_from_service(sync_id):
        try:
            ignore = ['flow_service.py', 'flow_engine.py', 'logger_system.py', 'flow_hud.py', 'flow_bridge.py']
            project_files = [f for f in os.listdir('.') if f.endswith('.py') and f not in ignore]
            
            if not project_files:
                log.error("❌ No user scripts found.")
                return
                
            target_script = max(project_files, key=os.path.getmtime)
            log.info(f"🔥 Auto-booting: {target_script}")

            os.environ["FLOW_SYNC_ID"] = sync_id
            
            spec = importlib.util.spec_from_file_location("__main__", os.path.abspath(target_script))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        except Exception as e:
            log.critical(f"💥 Engine Discovery Crash: {e}")

    @staticmethod
    def run_target(script_path, target_func, sync_id, params=None):
        abs_path = os.path.normpath(os.path.abspath(script_path))
        os.environ["FLOW_CURRENT_SCRIPT"] = abs_path
        
        # --- 🛡️ HUD PERSISTENCE CHECK ---
        try:
            with socket.create_connection(("127.0.0.1", 5555), timeout=0.1):
                log.info("🤝 HUD Link Verified.")
        except:
            log.warning("⚠️ HUD missing. Spawning UI...")
            subprocess.Popen(
                [sys.executable.replace("python.exe", "pythonw.exe"), "flow_hud.py"],
                creationflags=0x00000200 | 0x00000008 
            )
            time.sleep(1.2) 
        
        try:
            Flow.init(sync_id)
            
            # Pull the policy we set in launch()
            is_rt = os.environ.get("FLOW_REAL_TIME") == "TRUE"

            # UPDATED: Send a structured dict instead of a string for the HUD to parse easily
            Flow.pulse("SYSCALL: REFRESH", params={
                "mode": "LIVE", 
                "target": target_func.__name__,
                "real_time": is_rt
            })
            
            log.info(f"🚀 LIVE TRACE STARTING: {target_func.__name__} | Sync: {is_rt}")
            
            sys.settrace(trace_calls)
            try:
                # Handle param injection safely
                if params and inspect.signature(target_func).parameters:
                    target_func(**params)
                else:
                    target_func()
            finally:
                sys.settrace(None) 
                
            log.info(f"✅ LIVE Execution Finished.")
        except Exception as e:
            log.error(f"❌ Execution Error: {e}")
            # Ensure the HUD reflects the crash immediately
            Flow.pulse("ENGINE: FATAL", returns=str(e), type="nuke")


def trace_calls(frame, event, arg):
    filename = frame.f_code.co_filename
    func_name = frame.f_code.co_name
    
    if "logging" in filename or "flow_engine" in filename or "flow_bridge" in filename:
        return trace_calls 

    if os.environ.get("FLOW_BLAST_CRITICAL") == "TRUE":
        return None 

    target_file = os.environ.get("FLOW_CURRENT_SCRIPT")
    current_file = os.path.normpath(os.path.abspath(filename))

    if target_file and current_file == target_file:
        if func_name in ["<module>", "launch"]:
            return trace_calls

        fn_obj = frame.f_globals.get(func_name) or (frame.f_back.f_locals.get(func_name) if frame.f_back else None)

        # Sync Throttle Check
        # Sync Throttle Check
        # is_rt == TRUE means we want CPU speed (Instant)
        # is_rt == FALSE means we want Cinematic speed (Slow)
        is_rt = os.environ.get("FLOW_REAL_TIME") == "TRUE"

        if event == 'call':
            Flow.pulse(fn_obj or func_name, type="processing")
            # --- FLIPPED LOGIC HERE ---
            if not is_rt: 
                time.sleep(1.0) # The 2-3 second cinematic pause you wanted
            
        elif event == 'exception':
            os.environ["FLOW_BLAST_CRITICAL"] = "TRUE"
            Flow.pulse(fn_obj or func_name, type="nuke")
            return None
            
        elif event == 'return':
            Flow.pulse(fn_obj or func_name, returns=arg, type="success")
            # --- FLIPPED LOGIC HERE ---
            if not is_rt: 
                time.sleep(0.5) # Brief pause to see the green success state
    return trace_calls


def secure_gate(mode="LIVE"):
    """
    Handles environment muzzling and safety shims.
    mode: "SIMULATION" (Ghost) or "LIVE"
    """
    # 1. THE MUZZLE (Internal logging)
    if not os.environ.get("FLOW_DEBUG_MODE") == "TRUE":
        import logging
        for logger_name in [None, "FlowEngine", "FlowService"]:
            l = logging.getLogger(logger_name)
            for handler in l.handlers:
                if isinstance(handler, logging.StreamHandler):
                    handler.setLevel(logging.ERROR)

    # 2. THE SHIMS (Safety for Ghost Mode)
    if mode == "SIMULATION":
        # Shove data into inputs so Ghost doesn't hang
        builtins.input = lambda prompt="": "GHOST_DATA"
        # Trap sys.exit so the engine process doesn't die
        sys.exit = lambda code=None: (_ for _ in ()).throw(RuntimeError("Ghost Exit Trap"))
    else:
        # Restore for Live mode (assuming you saved originals globally or locally)
        # Note: In most cases, Live mode just uses the default Python behavior
        pass
 
 

def launch(func_name, Ghost=True,Real_Time=True,_func_ref=None, _params=None):
    """
    The master airlock. Switches from Scout (0) to Live (1).
    Ensures terminal handles and UI states are reset during handover.
    """

    # 🛡️ CAPTURE ORIGINALS
    orig_input, orig_exit = builtins.input, sys.exit
    orig_stdin = sys.stdin
    os.environ["FLOW_REAL_TIME"] = "TRUE" if Real_Time else "FALSE"

    try:
        # --- 1. RESOLUTION ---
        if _func_ref:
            target_func = _func_ref
            caller_file = os.environ.get("FLOW_CURRENT_SCRIPT")
        else:
            caller_frame = inspect.stack()[1].frame
            target_func = caller_frame.f_globals.get(func_name)
            caller_file = os.path.normpath(os.path.abspath(inspect.stack()[1].filename))
            os.environ["FLOW_CURRENT_SCRIPT"] = caller_file

        if not target_func:
            log.error(f"❌ Resolution Failed: '{func_name}' not found.")
            return
            
        sync_id = os.environ.get("FLOW_SYNC_ID", "DEV_SESH")

        # --- 2. EXECUTION BRANCHING ---
        if Ghost:
            # --- 🟢 GHOST SCOUT PASS (Mode 0) --
            Flow.mode = 0  # 0: GHOST RUN
            # 🚩 ADD THIS HERE: Wipe the old tail before the new scout starts
            Flow.pulse("SYSCALL: REFRESH", type="refresh")
            time.sleep(0.02) # Brief breather for the HUD to clear
            
            log.info(f"🔎 [PASS 1/2] GHOST SCOUT: Mapping {func_name}...")
            os.environ["FLOW_MODE"] = "SIMULATION"
            
            secure_gate(mode="SIMULATION")
            log.info(f"🔎 [PASS 1/2] GHOST SCOUT: Mapping {func_name}...")
            os.environ["FLOW_MODE"] = "SIMULATION"
            
            secure_gate(mode="SIMULATION")
            
            sig = inspect.signature(target_func)
            mock_params = {n: generate_ball(p.annotation) for n, p in sig.parameters.items()}
            
            try:
                sys.settrace(trace_calls) 
                target_func(**mock_params)
            except Exception as e:
                if "Ghost Exit Trap" not in str(e):
                    log.debug(f"ℹ️ Ghost Scout path break: {e}")
            finally:
                sys.settrace(None)

            # --- 🛰️ HANDOVER ---
            # 1. Flip Mode to LIVE (1)
            # Flow.mode = 1
            
            # 2. CLEAR HUD: Tell FlowHUD to reset all node colors to Grey/Pending
            # This is the fix for the "Ghost stayed Green" bug.
            # Flow.pulse("SYSCALL: REFRESH", type="refresh")
            # time.sleep(0.3)
            # # 3. Restore Terminal for recursive call
            # builtins.input, sys.exit = orig_input, orig_exit
            # sys.stdin = orig_stdin 
            
            # log.info(f"🔄 Scout Complete. Transitioning to LIVE RUN...")
            # launch(func_name, Ghost=False, _func_ref=target_func, _params=mock_params)
        
        else:
            # --- 🔴 LIVE EXECUTION PASS (Mode 1) ---
            Flow.mode = 1 # Ensure Mode is LIVE
            log.info(f"🔥 [PASS 2/2] LIVE EXECUTION: {func_name}")
            os.environ["FLOW_MODE"] = "LIVE"
            
            # Full Terminal Restore
            sys.stdin = orig_stdin 
            builtins.input, sys.exit = orig_input, orig_exit
            secure_gate(mode="LIVE")
            
            actual_params = _params if _params else {}
            
            # Static Engine Handoff
            FlowEngine.run_target(caller_file, target_func, sync_id, params=actual_params)

    except Exception as e:
        log.error(f"💥 Critical Launch Failure: {e}")
    finally:
        # --- 🏁 SYSTEM RECOVERY ---
        builtins.input, sys.exit = orig_input, orig_exit


def generate_ball(annotation):
    mapping = {int: 1, str: "mock_val", float: 1.0, bool: True, list: [], dict: {}, tuple: ()}
    return mapping.get(annotation, None)

if __name__ == "__main__":
    sid = os.environ.get("FLOW_SYNC_ID", "SERVICE_SESSION")
    FlowEngine.ignite_from_service(sid)