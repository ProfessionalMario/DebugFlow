import keyboard
import subprocess
import sys
import os
import time
import psutil
import traceback
import uuid
from . import log
from .flow_bridge import Flow
import signal

import os
import sys

try:
    # When running as a module (-m debugflow.flow_service)
    from . import log
except ImportError:
    # Fallback if the package context is lost
    import logging
    log = logging.getLogger("debugflow")

# This automatically connects to your LoggerSystem because it's under 'debugflow'
# log = logging.getLogger("debugflow.engine")
# --- GLOBAL CONSTANTS ---
# PYTHONW = sys.executable.replace("python.exe", "pythonw.exe")
CREATE_NO_WINDOW = 0x00000200
DETACHED_PROCESS = 0x00000008
class FlowSentinel:
    def __init__(self):
        self.last_trigger_time = 0
        self.debounce_duration = 0.7 
        # self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.hud_pid_file = os.path.join(self.base_dir, ".hud_pid")
        self.engine_pid_file = os.path.join(self.base_dir, ".engine_pid")
        self.hud_script = os.path.join(self.base_dir, "flow_hud.py")

    def _is_debouncing(self):
        """Strict mechanical debounce."""
        current_time = time.time()
        if current_time - self.last_trigger_time < self.debounce_duration:
            return True
        self.last_trigger_time = current_time
        return False

    def _get_pid_from_file(self, path):
        """Reads PID and verifies OS existence."""
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    pid = int(f.read().strip())
                if psutil.pid_exists(pid):
                    return pid
            except: pass
        return None

    def toggle_hud(self):
        """Service Mode: Toggle UI + Ghost Pipeline Draw."""
        if self._is_debouncing(): return

        active_pid = self._get_pid_from_file(self.hud_pid_file)

        if active_pid:
            log.info(f"🔪 HUD Active (PID {active_pid}). Executing Kill...")
            self._force_kill_hud()
        else:
            # Clean up dead lockfiles
            if os.path.exists(self.hud_pid_file): os.remove(self.hud_pid_file)
                
            log.info("🚀 HUD Dormant. Spawning Instance & Ghost Pipeline...")
            # Create a copy of the current environment
            env = os.environ.copy()
            env["FLOW_UI_ALLOWED"] = "TRUE" # The Badge

            # 1. Spawn the HUD with the Badge
            proc = subprocess.Popen(
                [PYTHONW, self.hud_script],
                cwd=self.base_dir,
                env=env, # Pass the badge here!
                creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS
            )
            # # 1. Spawn the HUD
            # proc = subprocess.Popen(
            #     [PYTHONW, self.hud_script],
            #     cwd=self.base_dir,
            #     creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS
            # )
            with open(self.hud_pid_file, "w") as f:
                f.write(str(proc.pid))
            
            # 2. Sync with Ghost Pipeline
            # Allow HUD socket a split second to bind
            time.sleep(0.5)
            self.ignite_ghost_pipeline()

    def ignite_ghost_pipeline(self):
        """Triggers the existing ghost flow to draw the project architecture."""
        try:
            sync_id = "GHOST_DRAW"
            # Path for the engine execution
            engine_cmd = (
                f"import sys; sys.path.append(r'{self.base_dir}'); "
                f"from flow_engine import FlowEngine; "
                f"FlowEngine.ignite_from_service('{sync_id}')" 
            )

            # We use the detached flag so the Service doesn't hang on the engine
            subprocess.Popen(
                [PYTHONW, "-c", engine_cmd],
                cwd=self.base_dir,
                creationflags=CREATE_NO_WINDOW
            )
            log.info("📊 Ghost Pipeline: Architecture Snapshot Sent.")
        except Exception as e:
            log.error(f"Ghost Ignition Failed: {e}")

    def _force_kill_hud(self):
        """Standard surgical cleanup."""
        pid = self._get_pid_from_file(self.hud_pid_file)
        if pid:
            try:
                p = psutil.Process(pid)
                for child in p.children(recursive=True): child.kill()
                p.kill()
                log.info(f"Surgical Kill Success: {pid}")
            except: pass
            finally:
                if os.path.exists(self.hud_pid_file): os.remove(self.hud_pid_file)
    
    def log_save_event(self):
        """
        Triggered by Ctrl+S. 
        Only ignites the engine if the HUD is physically detected in the OS.
        """
        if self._is_debouncing(): return

        try:
            # 1. THE REALITY CHECK (Stateless)
            active_hud_pid = self._get_pid_from_file(self.hud_pid_file)
            
            # If no PID file or process is dead, we stay dormant
            if not (active_hud_pid and psutil.pid_exists(active_hud_pid)):
                return 

            # 2. SURGICAL CLEANUP (Engine)
            # Kill any lingering engine runs before starting a new one
            old_engine_pid = self._get_pid_from_file(self.engine_pid_file)
            if old_engine_pid and psutil.pid_exists(old_engine_pid):
                try:
                    psutil.Process(old_engine_pid).terminate()
                    log.info(f"🔪 Terminated stale engine (PID {old_engine_pid})")
                except: pass

            # 3. PREPARE NEW SESSION
            sync_id = str(uuid.uuid4())[:8]
            log.info(f"📡 HUD Linked. Launching Session: {sync_id}")

            engine_cmd = (
                f"import sys; sys.path.append(r'{self.base_dir}'); "
                f"from flow_engine import FlowEngine; "
                f"FlowEngine.ignite_from_service('{sync_id}')" 
            )

            # 4. LAUNCH & REGISTER
            new_engine = subprocess.Popen(
                [PYTHONW, "-c", engine_cmd],
                cwd=self.base_dir,
                creationflags=CREATE_NO_WINDOW
            )
            
            # Record the engine PID so we can kill it on the next Ctrl+S
            with open(self.engine_pid_file, "w") as f:
                f.write(str(new_engine.pid))
            
        except Exception as e:
            log.error(f"Failed to sync save event: {e}")
    
    def start_listening(self):
        """Entry point for the background daemon"""
        try:
            keyboard.unhook_all()
            keyboard.add_hotkey('ctrl+alt+f', self.toggle_hud)
            keyboard.add_hotkey('ctrl+s', self.log_save_event)
            log.info("System Hooks Active. Sentinel in Standby.")
            keyboard.wait()
        except Exception as e:
            log.error(f"Sentinel Loop Fatal Error: {e}")

def is_service_running():
    try:
        current_pid = os.getpid()
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            cmdline = proc.info.get('cmdline')
            if not cmdline: continue
            
            # Join cmdline into a single string to search
            cmd_str = " ".join(cmdline)
            
            # Look for our specific service signature
            if "flow_service" in cmd_str and "start_listening" in cmd_str:
                if proc.info['pid'] != current_pid:
                    return proc
    except Exception:
        pass
    return None

def activate():
    # 1. Clean up
    kill_signal = os.path.join(os.path.dirname(__file__), ".die")
    if os.path.exists(kill_signal):
        os.remove(kill_signal)

    existing_proc = is_service_running()

    # --- TOGGLE LOGIC (OFF) ---
    if existing_proc:
        # If we are in a normal terminal (not pythonw), kill the background dude
        if "pythonw.exe" not in sys.executable.lower():
            sentinel = FlowSentinel()
            sentinel._force_kill_hud() 
            try:
                existing_proc.kill()
                time.sleep(0.2) 
            except: pass
            
            print("\n  [!] SYNAPSE DISCONNECTED")
            print("  ✖ NEURALFLOW: DEACTIVATED\n")
            sys.exit(0)

    # --- START SERVICE (ON) ---
    # PYTHONW = sys.executable.replace("python.exe", "pythonw.exe")
    PYTHONW = sys.executable  # force python.exe
    # Using 0x08... for CREATE_NO_WINDOW
    CREATE_NO_WINDOW = 0x08000000 
    DETACHED_PROCESS = 0x00000008
    
    # FIX: Don't use a string command. Call the module directly!
    # This ensures 'from . import log' and other imports don't break.
    subprocess.Popen(
        [PYTHONW, "-m", "debugflow.flow_service"], 
        creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS, 
        close_fds=True
    )

    # --- 🖥️ THE NEURAL DASHBOARD ---
    print("\n" + "═"*50)
    print("  ✔  NEURALFLOW: ENGINE ACTIVATED")
    print("═"*50)
    print("  [NODE PROTOCOLS]")
    print("  🟡 YELLOW : Processing (Active Thread)")
    print("  🟢 GREEN  : Success    (Data Synapse)")
    print("  🔴 RED    : Nuke       (Point of Failure)")
    print("─"*50)
    print("  [EXECUTION MODES]")
    print("  👻 GHOST  : Non-destructive Logic Mapping")
    print("  ⏳ LIVE   : Real-time Production Trace")
    print("─"*50)
    print("  [SYSTEM CONTROLS]")
    print("  • CTRL + ALT + F : Toggle HUD & Ghost Sync")
    print("  • CTRL + S       : Auto-Trace (If HUD is open)")
    print("  • flow activate  : Deactivate NeuralFlow")
    print("═"*50)
    print("  Sentinel is monitoring the nervous system...\n")


def get_pythonw():
    exe = sys.executable
    base = os.path.dirname(exe)

    pythonw = os.path.join(base, "pythonw.exe")
    if os.path.exists(pythonw):
        return pythonw

    # fallback: just use current executable
    return exe

PYTHONW = get_pythonw()


if __name__ == "__main__":
    # This part runs ONLY in the background process
    # It ensures the Sentinel starts its loop
    try:
        sentinel = FlowSentinel()
        sentinel.start_listening()
    except Exception as e:
        log.error(f"Background Startup Failed: {e}")